import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DiscoveryTab extends StatelessWidget {
  const  DiscoveryTab({super.key});
   // TODO: implement


  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Discovery'),
      ),
    );
  }
}
